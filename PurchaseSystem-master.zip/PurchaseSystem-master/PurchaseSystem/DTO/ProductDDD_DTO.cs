﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PurchaseSystem.DTO
{
    public class ProductDDD_DTO
    {
        public int productId { get; set; }
        public string ProductName { get; set; }
    }
}