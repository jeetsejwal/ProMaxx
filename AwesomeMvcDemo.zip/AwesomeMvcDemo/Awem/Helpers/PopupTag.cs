namespace Omu.Awem.Helpers
{
    internal class PopupTag
    {
        public bool? Occ { get; set; }

        public bool Dd { get; set; }

        public bool? Sh { get; set; }

        public bool Tg { get; set; }

        public bool Inline { get; set; }
    }
}