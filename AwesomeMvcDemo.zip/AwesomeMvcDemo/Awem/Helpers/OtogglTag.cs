namespace Omu.Awem.Helpers
{
    internal class OtogglTag
    {
        public string Width { get; set; }

        public string Yes { get; set; }

        public string No { get; set; }
    }
}