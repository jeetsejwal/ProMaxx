namespace Omu.Awem.Helpers
{
    internal class TimePickerTag : ComboboxTag
    {
        public string[] AmPm { get; set; }

        public int Step { get; set; }
    }
}