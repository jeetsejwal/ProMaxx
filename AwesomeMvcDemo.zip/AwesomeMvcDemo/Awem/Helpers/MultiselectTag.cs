namespace Omu.Awem.Helpers
{
    internal class MultiselectTag : ComboboxTag
    {
        public bool Reorderable { get; set; }

        public bool Combo { get; set; }

        public bool GenKey { get; set; }
    }
}