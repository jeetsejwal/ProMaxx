namespace Omu.Awem.Helpers
{
    internal class PopupButtonTag
    {
        public string[] K { get; set; }

        public string[] V { get; set; }
    }
}