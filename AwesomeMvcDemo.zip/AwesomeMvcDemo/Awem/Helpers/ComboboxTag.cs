namespace Omu.Awem.Helpers
{
    internal class ComboboxTag : OdropdownTag
    {
        public bool UseConVal { get; set; }

        public bool ClsEq { get; set; }

        public bool? CmbItm { get; set; }

        public bool Sof { get; set; }
    }
}