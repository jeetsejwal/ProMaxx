ASP.net MVC Awesome v. 6.3 Demo

built using VS2019

the nuget packages should restore automatically on first build (Starting with NuGet 2.7, package restore consent is ON by default)
if that doesn't happen go to
Options-> NuGet Package Manager -> General { check Allow Nuget to download missing packages and Automatically check for missing packages }

our forums: https://www.aspnetawesome.com/Forum

contact us: https://www.aspnetawesome.com/ContactUs

documentation, support: https://www.aspnetawesome.com