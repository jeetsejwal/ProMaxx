var awedict = {
    Empty: 'nada',
    GridInfo: "de {0}",
    Select: 'seleccione',
    SearchForRes: 'buscar más resultados',    
    NoRecFound: 'nada encontrado',
    PageSize: 'tamaño de página',
    Months: [
        "enero","febrero","marzo","abril","mayo","junio",
	"julio","agosto","septiembre","octubre","noviembre","diciembre"
    ],
    Days: ["D","L","M","X","J","V","S"],
    Yes: 'Si',
    No: 'No',
    Cancel: 'Cancelar',
    Ok: 'Ok',
    GridGroupBar: 'Arrastra un encabezado de columna y suéltalo aquí para agrupar',
    More: 'más',
    Search: 'Búsqueda'
};

//export {awedict};