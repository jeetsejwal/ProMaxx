var awedict = {
    Empty: 'rien',
    GridInfo: "de {0}",
    Select: 'choisir',
    SearchForRes: 'rechercher plus de résultats',    
    NoRecFound: 'rien n\'a été trouvé',
    PageSize: 'taille de la page',
    Months: [
        "janvier", "février", "mars", "avril", "mai", "juin",
		"juillet", "août", "septembre", "octobre", "novembre", "décembre"
    ],
    Days: ["D","L","M","M","J","V","S"],
    Yes: 'Oui',
    No: 'Non',
    Cancel: 'Anuller',
    Ok: 'Ok',
    GridGroupBar: 'Faites glisser un en-tête de colonne ici pour grouper',
    More: 'plus',
    Search: 'Recherche'
};

//export {awedict};