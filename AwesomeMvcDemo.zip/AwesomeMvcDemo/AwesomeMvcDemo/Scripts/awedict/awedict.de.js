var awedict = {
    Empty: 'nichts',
    GridInfo: "von {0} items",
    Select: 'Bitte auswählen',
    SearchForRes: 'Suche nach mehr Ergebnissen',
    NoRecFound: 'Nichts gefunden',
    PageSize: 'Seitengröße',
    Months: [
        "Januar","Februar","März","April","Mai","Juni",
	"Juli","August","September","Oktober","November","Dezember"
    ],
    Days: ["So","Mo","Di","Mi","Do","Fr","Sa"],
    Yes: 'Ja',
    No: 'Nein',
    Cancel: 'Abbrechen',
    Ok: 'Ok',
    GridGroupBar: 'Ziehen Sie eine Spalte hierher, um sie zu gruppieren',
    More: 'Mehr',
    Search: 'Suche'
};

//export {awedict};