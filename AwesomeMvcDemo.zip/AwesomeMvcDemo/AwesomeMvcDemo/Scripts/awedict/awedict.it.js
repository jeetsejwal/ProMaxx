var awedict = {
    Empty: 'niente',
    GridInfo: "di {0}",
    Select: 'selezionare',
    SearchForRes: 'cerca per trovare più risultati',
    NoRecFound: 'non abbiamo trovato nulla',
    PageSize: 'dimensioni della pagina',
    Months: [
        "Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno",
		"Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"
    ],
    Days: ["Do","Lu","Ma","Me","Gi","Ve","Sa"],
    Yes: 'Si',
    No: 'No',
    Cancel: 'Annulla',
    Ok: 'Ok',
    GridGroupBar: 'Trascina una colonna qui per raggruppare',
    More: 'di più',
    Search: 'Cerca'
};

//export {awedict};