var awedict = {
    Empty: 'nimic',
    GridInfo: "din {0} itemi",
    Select: 'selectați',
    SearchForRes: 'caută pentru mai multe rezultate',    
    NoRecFound: 'nimic găsit',
    PageSize: 'mărimea paginii',
    Months: [
        "Ianuarie","Februarie","Martie","Aprilie","Mai","Iunie",
	"Iulie","August","Septembrie","Octombrie","Noiembrie","Decembrie"
    ],
    Days: ["Du","Lu","Ma","Mi","Jo","Vi","Sâ"],
    Yes: 'Da',
    No: 'Nu',
    Cancel: 'Anulare',
    Ok: 'Ok',
    GridGroupBar: 'Trageți un antet de coloană aici pentru a grupa',
    More: 'mai mult',
    Search: 'Caută'
};

//export {awedict};