namespace AwesomeMvcDemo.ViewModels
{
    public class GridArrayRow
    {
        public string Id { get; set; }

        public string[] Values { get; set; }
    }
}