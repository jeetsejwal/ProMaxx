namespace AwesomeMvcDemo.ViewModels.Input.Settings
{
    public class SettingsVal
    {
        public string Theme { get; set; }
    }
}