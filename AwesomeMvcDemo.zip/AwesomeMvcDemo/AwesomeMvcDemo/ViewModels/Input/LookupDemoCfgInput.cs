namespace AwesomeMvcDemo.ViewModels.Input
{
    public class LookupDemoCfgInput
    {
        public int? Meal { get; set; }

        public bool ClearButton { get; set; }

        public bool HighlightChange { get; set; }

        public bool Fullscreen { get; set; }
    }
}