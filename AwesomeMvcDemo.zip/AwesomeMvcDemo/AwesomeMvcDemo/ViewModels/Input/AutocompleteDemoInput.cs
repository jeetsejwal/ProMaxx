namespace AwesomeMvcDemo.ViewModels.Input
{
    public class AutocompleteDemoInput
    {
        public string Meal { get; set; }

        public string Meal3 { get; set; }

        public int? MealKey { get; set; }

        public int PrimeNumber { get; set; }

        public string ChildMeal { get; set; }

        public int[] CategoriesData { get; set; }

        public string ChildOfManyMeal { get; set; }

        public string Meal1 { get; set; }
        public string Meal2 { get; set; }
    }
}