namespace AwesomeMvcDemo.ViewModels.Input
{
    public class ApiParamsInput
    {
        public int Page { get; set; }
        public string Parent { get; set; }
    }
}