namespace AwesomeMvcDemo.ViewModels.Input
{
    public class DeleteConfirmInput
    {
        public int Id { get; set; }

        public string Type {get;set; }

        public string Name { get; set; }
    }
}