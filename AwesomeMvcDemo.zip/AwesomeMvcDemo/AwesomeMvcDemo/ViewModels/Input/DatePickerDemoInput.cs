using System;

namespace AwesomeMvcDemo.ViewModels.Input
{
    public class DatePickerDemoInput
    {
        public DateTime? Date { get; set; }

        public DateTime? DateInline { get; set; }

        public DateTime? Date2 { get; set; }

        public DateTime? Date3 { get; set; }

        public DateTime? Date4 { get; set; }

        public DateTime? DateFrom { get; set; }

        public DateTime? DateTo { get; set; }
    }
}