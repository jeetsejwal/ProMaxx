namespace AwesomeMvcDemo.ViewModels.Input
{
    public class TextBoxDemoInput
    {
        public string Name { get; set; }

        public decimal Number { get; set; }
    }
}