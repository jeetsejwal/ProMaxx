namespace AwesomeMvcDemo.ViewModels.Input
{
    public class GridHideColumnsDemoInput
    {
        public bool ShowFood { get; set; }

        public bool ShowLocation { get; set; }

        public bool ShowDate { get; set; }
    }
}