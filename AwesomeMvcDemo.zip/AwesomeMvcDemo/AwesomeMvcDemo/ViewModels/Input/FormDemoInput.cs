namespace AwesomeMvcDemo.ViewModels.Input
{
    public class FormDemoInput
    {
        public string Word { get; set; }
    }
}