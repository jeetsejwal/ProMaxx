namespace AwesomeMvcDemo.ViewModels.Input.Wizard
{
    public class WizardModel
    {
        public string Id { get; set; }

        public Step1Model Step1 { get; set; }

        public Step2Model Step2 { get; set; }
    }
}