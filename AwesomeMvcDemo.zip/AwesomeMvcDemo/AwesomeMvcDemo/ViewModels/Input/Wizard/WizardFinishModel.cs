namespace AwesomeMvcDemo.ViewModels.Input.Wizard
{
    public class WizardFinishModel
    {
        public string WizardId { get; set; }

        public string Category { get; set; }

        public string[] Meals { get; set; }

        public string Name { get; set; }
    }
}