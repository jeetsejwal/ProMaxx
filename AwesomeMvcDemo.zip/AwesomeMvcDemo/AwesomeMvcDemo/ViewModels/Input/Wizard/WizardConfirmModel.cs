namespace AwesomeMvcDemo.ViewModels.Input.Wizard
{
    public class WizardConfirmModel
    {
        public string WizardId { get; set; }
    }
}