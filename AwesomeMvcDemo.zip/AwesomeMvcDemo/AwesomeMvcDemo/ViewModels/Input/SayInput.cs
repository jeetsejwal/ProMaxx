namespace AwesomeMvcDemo.ViewModels.Input
{
    public class SayInput
    {
        public string SaySomething { get; set; }
    }
}