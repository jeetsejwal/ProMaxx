namespace AwesomeMvcDemo.ViewModels.Input.Lookup
{
    public class LookupPopupInput
    {
        public string Search { get; set; }
    }
}