using System.ComponentModel.DataAnnotations;

namespace AwesomeMvcDemo.ViewModels.Input
{
    public class LookupCrudDemoInput
    {
        [Required]
        public int? Dinner2 { get; set; }

        [Required]
        public int[] Dinner3 { get; set; }
    }
}