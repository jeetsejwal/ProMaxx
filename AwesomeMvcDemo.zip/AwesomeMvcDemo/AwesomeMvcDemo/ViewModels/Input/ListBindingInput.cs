using System.Collections.Generic;

namespace AwesomeMvcDemo.ViewModels.Input
{
    public class ListBindingInput
    {
        public IList<DinnerInput> Dinners { get; set; }
    }
}