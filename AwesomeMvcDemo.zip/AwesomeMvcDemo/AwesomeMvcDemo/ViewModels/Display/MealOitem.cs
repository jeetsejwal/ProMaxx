using Omu.Awem.Helpers;

namespace AwesomeMvcDemo.ViewModels.Display
{
    public class MealOitem : Oitem
    {
        public string url { get; set; }
    }
}