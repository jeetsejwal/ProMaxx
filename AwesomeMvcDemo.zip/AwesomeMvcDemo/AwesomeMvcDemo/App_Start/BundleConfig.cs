using System.Web.Optimization;

namespace AwesomeMvcDemo.App_Start
{
    public static class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundle/Scripts/js").Include(
                "~/Scripts/AwesomeMvc.js",
                "~/Scripts/awem.js",
                "~/Scripts/utils.js",
                "~/Scripts/sidemenu.js",
                "~/Scripts/signalrSync.js",
                "~/Scripts/aweui.js",
                "~/Scripts/awedict.js",
                "~/Scripts/Site.js",
                "~/Scripts/storg.js", // used to save sidemenu data in sessionStorage
                "~/Scripts/infra/aweq.js", // used in grid client data demo
                "~/Scripts/infra/formBuilder.js" // used in grid filtering demo
                ));
        }
    }
}