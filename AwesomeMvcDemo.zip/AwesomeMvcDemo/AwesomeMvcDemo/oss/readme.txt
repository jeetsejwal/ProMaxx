oss

https://github.com/omuleanu/oss