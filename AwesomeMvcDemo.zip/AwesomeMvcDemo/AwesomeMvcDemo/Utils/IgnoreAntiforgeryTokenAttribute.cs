using System.Web.Mvc;

namespace AwesomeMvcDemo.Utils
{
    public class IgnoreAntiforgeryTokenAttribute : FilterAttribute
    {
    }
}