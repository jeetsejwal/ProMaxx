using System.Web.Mvc;

namespace AwesomeMvcDemo.Controllers
{
    public class SitemapController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}