using System.Web.Mvc;

namespace AwesomeMvcDemo.Controllers.Demos.Grid
{
    public class KeyboardNavigationDemoController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}