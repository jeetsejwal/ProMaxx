using System.Linq;
using System.Web.Mvc;

using AwesomeMvcDemo.Models;

using Omu.AwesomeMvc;

namespace AwesomeMvcDemo.Controllers.Demos.Grid
{
    public class CascadingGridDemoController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}