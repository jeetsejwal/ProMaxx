using System.Web.Mvc;

namespace AwesomeMvcDemo.Controllers.Demos.Grid
{
    public class GridShowHideColumnsApiDemoController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}