using System.Web.Mvc;

namespace AwesomeMvcDemo.Controllers.Demos.Grid
{
    public class GridClientDataDemoController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}