using System.Web.Mvc;

namespace AwesomeMvcDemo.Controllers.Demos.Grid
{
    public class GridInfiniteScrollingDemoController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}