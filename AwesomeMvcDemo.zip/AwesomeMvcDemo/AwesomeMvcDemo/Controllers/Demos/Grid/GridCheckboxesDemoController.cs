using System.Web.Mvc;

namespace AwesomeMvcDemo.Controllers.Demos.Grid
{
    public class GridCheckboxesDemoController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}