using System.Web.Mvc;
using AwesomeMvcDemo.Models;
using AwesomeMvcDemo.ViewModels.Input;
using Omu.Awem.Utils;

namespace AwesomeMvcDemo.Controllers.Demos.Grid.MasterDetailCrud
{
    public class RestInlController : Controller
    {
        public ActionResult Addresses(int key)
        {
            ViewData["Id"] = key;
            return PartialView();
        }

        private object MapToGridModel(Restaurant o)
        {
            return new { o.Id, o.Name };
        }

        [HttpPost]
        public ActionResult Create(RestaurantInput input)
        {
            if (!ModelState.IsValid)
            {
                return Json(ModelState.GetErrorsInline());
            }

            var ent = Db.Insert(new Restaurant
            {
                Name = input.Name,
                IsCreated = true
            });

            return Json(new { Item = MapToGridModel(ent) });

        }

        [HttpPost]
        public ActionResult Edit(RestaurantInput input)
        {
            if (!ModelState.IsValid)
            {
                return Json(ModelState.GetErrorsInline());
            }

            var ent = Db.Get<Restaurant>(input.Id);
            ent.Name = input.Name;
            Db.Update(ent);

            return Json(new { });
        }
    }
}