using System.Web.Mvc;

namespace AwesomeMvcDemo.Controllers.Demos.Misc
{
    public class AngularDemoController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}