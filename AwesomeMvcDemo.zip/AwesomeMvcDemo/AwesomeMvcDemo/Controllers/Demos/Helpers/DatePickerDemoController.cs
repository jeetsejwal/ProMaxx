using System.Web.Mvc;

namespace AwesomeMvcDemo.Controllers.Demos.Helpers
{
    public class DatePickerDemoController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}