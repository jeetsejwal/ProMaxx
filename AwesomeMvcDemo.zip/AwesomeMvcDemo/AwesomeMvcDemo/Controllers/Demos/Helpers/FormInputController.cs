using System.Web.Mvc;

namespace AwesomeMvcDemo.Controllers.Demos.Helpers
{
    public class FormInputController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}