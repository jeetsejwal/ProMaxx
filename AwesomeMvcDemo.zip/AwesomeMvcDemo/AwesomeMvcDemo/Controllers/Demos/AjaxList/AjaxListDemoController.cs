using System.Web.Mvc;

namespace AwesomeMvcDemo.Controllers.Demos.AjaxList
{
    public class AjaxListDemoController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult CustomItemTemplate()
        {
            return View();
        }

        public ActionResult TableLayout()
        {
            return View();
        }

        public ActionResult ClientSideApi()
        {
            return View();
        }

        public ActionResult Crud()
        {
            return View();
        }
    }
}