using System.Web.Mvc;

namespace AwesomeMvcDemo.Controllers.Demos.Generic
{
    public class MultipleLevelCascadingDemoController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}