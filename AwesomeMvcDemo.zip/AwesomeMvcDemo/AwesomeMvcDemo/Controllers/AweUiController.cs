using System.Web.Mvc;

namespace AwesomeMvcDemo.Controllers
{
    public class AweUiController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}