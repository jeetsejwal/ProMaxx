namespace AwesomeMvcDemo.Models
{
    public class DemoSettings
    {
        public const string DefaultTheme = "mui";
        public static string MobileTheme = "mui";
        public const string CookieName = "awedemset2";
    }
}