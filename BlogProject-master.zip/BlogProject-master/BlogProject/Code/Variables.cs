﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BlogProject.Code
{
    public static class Variables
    {
        public static int NoOfPosts = 6;
    }
}