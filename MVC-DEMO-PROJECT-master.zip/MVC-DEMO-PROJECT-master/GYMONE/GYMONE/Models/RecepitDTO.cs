﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GYMONE.Models
{
    public class RecepitDTO
    {
        public string SearchButton { get; set; }
        public string PaymentSearch { get; set; }
        public string MembernoSearch { get; set; }
        public string MemberName { get; set; }
    }
}